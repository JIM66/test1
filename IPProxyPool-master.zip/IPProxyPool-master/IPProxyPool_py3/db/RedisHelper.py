#coding:utf-8
from db.ISqlHelper import ISqlHelper


class RedisHelper(ISqlHelper):

    def __init__(self):
        pass
    def init_db(self):
        pass


    def drop_db(self):
        pass


    def insert(self,value):
        pass


    def delete(self, conditions):
        pass

    def update(self, conditions,value):
        pass

    def select(self, count=None,conditions=[]):
        pass


