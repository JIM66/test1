#coding:utf-8
from lxml import etree

__author__ = 'Xaxdus'

html='''

<!doctype html public "-//w3c//dtd xhtml 1.0 transitional//en" "http://www.w3.org/tr/xhtml1/dtd/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>北京http代理ip_66免费代理ip提取网</title><meta http-equiv="Content-Type" content="text/html; charset=gb2312"/>
<meta name="keywords" content="ip提取，http代理，国内外代理，免费高匿名代理，免费ip提取网站，ip代理提取，免费ip代理,代理ip,ip代理,ip代理软件"/>
<meta name="description" content="66免费ip代理网时时更新最新免费代理ip、http代理为主,常年提供免费代理ip、qq代理ip、https匿名代理、国内代理软件等加速服务，为用户提供最优质代理."/>
<meta name=generator content="mshtml 8.00.7601.17514">
<script type="text/javascript" src="/common/js/public.js"></script>
<script type="text/javascript" src="/common/js/app.js"></script>
<link rel="stylesheet" type="text/css" href="/common/css/main.css"/>
</head>
<body>
<div id="header" class="header">
<div class="logoarea">
<a class="logo left block" href=""><img src="/common/tp/logo.gif" alt="66免费ip代理网LOGO" height="65"></a>
<div class="clr">
<div align="right">
<a href="index.html"></a>
<ul class="textlarge" style="padding-top:12px">
<a href="/zh.php">祝贺:网站会员已经开通在线支付功能,支持支付宝.财付通.微信,付款购买会员点击购买!
<a href="http://www.66ip.cn/zh.php" rel="nofollow" target="_blank"><img src="/common/img/yaoyao.jpg" border="0"></a>
</ul>
</div>
</div>
</div>
<div class="navigator">
<div align="center">
<ul class="textlarge">
<li><a href="/index.html">网站首页</a></li>
<li><a href="/pt.html">免费HTTP提取</a></li>
<li><a href="/nm.html">免费匿名IP提取</a></li>
<li><a href="/rj.html">免费软件IP提取</a></li>
<li><a href="/yz">在线代理IP检测</a></li>
<li><a href="/zz.html">收费会员IP提取</a></li>
<li><a href="/zh.php">收费购买IP价格</a></li>
<li><a class="logo left block" href="tencent://message/?uin=709295847&amp;site=客服&amp;menu=yes"><img src="/common/tp/qq.gif" alt="QQ客服" width="77" height="22" border="0" align="right"></a></li>
</ul>
</div>
</div>
</div>
<div style="margin-top:10px">
<table style="width:959px;margin:0 auto;border:1px solid #ccc;border-collapse:collapse" cellpadding="0" cellspacing="0">
<tr>
<td>
<p>
<a href="http://shang.qq.com/wpa/qunwpa?idkey=21cc6c4df48771b2049764bbc76a51fb9df9627e6096c14378f8f1bef78a2e8f" target="_blank"><img src="/klz/953X164.gif" alt="免流量" border="0"></a>
</p>
</td>
</tr>
<tr>
<td>
</td>
</tr>
</table>
</div>
<div style="margin-top:10px;">
<table cellspacing="0" cellpadding="0" style="width:959px;margin:0 auto;border:1px solid #cccccc;border-collapse:collapse;">
<tr>
<td style="padding-right:0px;">
<ul class="textlarge22">
<li><a href="http://www.66ip.cn">全国代理ip</a> </li>
<li class="myactive"><a href="/areaindex_1/1.html">北京代理ip</a> </li>
<li><a href="/areaindex_2/1.html">上海代理ip</a> </li>
<li><a href="/areaindex_3/1.html">天津代理ip</a> </li>
<li><a href="/areaindex_4/1.html">重庆代理ip</a> </li>
<li><a href="/areaindex_5/1.html">河北代理ip</a> </li>
<li><a href="/areaindex_6/1.html">山西代理ip</a> </li>
<li><a href="/areaindex_7/1.html">辽宁代理ip</a> </li>
<li><a href="/areaindex_8/1.html">吉林代理ip</a> </li>
<li><a href="/areaindex_9/1.html">黑龙江代理ip</a> </li>
<li><a href="/areaindex_10/1.html">江苏代理ip</a> </li>
<li><a href="/areaindex_11/1.html">浙江代理ip</a> </li>
<li><a href="/areaindex_12/1.html">安徽代理ip</a> </li>
<li><a href="/areaindex_13/1.html">福建代理ip</a> </li>
<li><a href="/areaindex_14/1.html">江西代理ip</a> </li>
<li><a href="/areaindex_15/1.html">山东代理ip</a> </li>
<li><a href="/areaindex_16/1.html">河南代理ip</a> </li>
<li><a href="/areaindex_17/1.html">湖北代理ip</a> </li>
<li><a href="/areaindex_18/1.html">湖南代理ip</a> </li>
<li><a href="/areaindex_19/1.html">广东代理ip</a> </li>
<li><a href="/areaindex_20/1.html">海南代理ip</a> </li>
<li><a href="/areaindex_21/1.html">四川代理ip</a> </li>
<li><a href="/areaindex_22/1.html">贵州代理ip</a> </li>
<li><a href="/areaindex_23/1.html">云南代理ip</a> </li>
<li><a href="/areaindex_24/1.html">陕西代理ip</a> </li>
<li><a href="/areaindex_25/1.html">甘肃代理ip</a> </li>
<li><a href="/areaindex_26/1.html">青海代理ip</a> </li>
<li><a href="/areaindex_27/1.html">台湾代理ip</a> </li>
<li><a href="/areaindex_28/1.html">内蒙古代理ip</a> </li>
<li><a href="/areaindex_29/1.html">广西代理ip</a> </li>
<li><a href="/areaindex_30/1.html">西藏代理ip</a> </li>
<li><a href="/areaindex_31/1.html">宁夏代理ip</a> </li>
<li><a href="/areaindex_32/1.html">新疆代理ip</a> </li>
<li><a href="/areaindex_33/1.html">香港代理ip</a> </li>
<li><a href="/areaindex_34/1.html">澳门代理ip</a> </li>
</ul>
</td>
</tr>
</table>
</div>
</ul></div></div>
<div id=main class=container>
<div class="containerbox boxindex">
<div>
<div>
<div class=style1>
<div align="center"></div>
</div>
<div id="footer" class="footer">
<div align="center">
<p>

<span class="style6">新界面-新ip-高质量-新功能-多ip</span></p>
<p class="style6">更多http-https追求更高的质量</p>
<p class="style6">ip地区表格数量会出现误差请不要大量对比</p>
<p>
</p>
<p class="style7">北京代理总数 <span style="color:red;">165</span></p>
<table width='100%' border="2px" cellspacing="0px" bordercolor="#6699ff">
<tr><td>ip</td><td>端口号</td><td>代理位置</td><td>代理类型</td><td>验证时间</td></tr>
<tr><td>124.206.56.125</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日13时 验证</td></tr><tr><td>115.25.138.245</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日13时 验证</td></tr><tr><td>180.76.189.148</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日12时 验证</td></tr><tr><td>180.76.189.148</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日12时 验证</td></tr><tr><td>123.119.27.67</td><td>8118</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日12时 验证</td></tr><tr><td>123.119.27.67</td><td>8118</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日12时 验证</td></tr><tr><td>115.183.11.158</td><td>9999</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日11时 验证</td></tr><tr><td>118.26.226.157</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日11时 验证</td></tr><tr><td>115.25.138.245</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日10时 验证</td></tr><tr><td>101.251.247.82</td><td>10000</td><td>北京市海淀区</td><td>高匿代理</td><td>2016年07月19日10时 验证</td></tr><tr><td>182.48.102.2</td><td>9000</td><td>北京市海淀区</td><td>高匿代理</td><td>2016年07月19日09时 验证</td></tr><tr><td>203.91.121.74</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日09时 验证</td></tr><tr><td>111.202.112.169</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日08时 验证</td></tr><tr><td>118.244.239.2</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日08时 验证</td></tr><tr><td>119.254.84.90</td><td>80</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日07时 验证</td></tr><tr><td>119.254.84.90</td><td>80</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日07时 验证</td></tr><tr><td>123.124.168.107</td><td>80</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日07时 验证</td></tr><tr><td>123.124.168.107</td><td>80</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日07时 验证</td></tr><tr><td>101.200.174.11</td><td>3128</td><td>北京市海淀区</td><td>高匿代理</td><td>2016年07月19日06时 验证</td></tr><tr><td>125.39.118.163</td><td>18000</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日06时 验证</td></tr><tr><td>182.61.9.177</td><td>80</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日05时 验证</td></tr><tr><td>118.26.226.157</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日05时 验证</td></tr><tr><td>118.26.226.157</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日05时 验证</td></tr><tr><td>182.61.9.177</td><td>80</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日05时 验证</td></tr><tr><td>182.61.7.193</td><td>80</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日04时 验证</td></tr><tr><td>111.202.112.169</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日04时 验证</td></tr><tr><td>203.91.121.74</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日03时 验证</td></tr><tr><td>116.213.102.66</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日03时 验证</td></tr><tr><td>118.244.239.2</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日02时 验证</td></tr><tr><td>124.16.70.20</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日02时 验证</td></tr><tr><td>219.141.225.149</td><td>80</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日01时 验证</td></tr><tr><td>203.91.121.74</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日01时 验证</td></tr><tr><td>182.48.102.2</td><td>9000</td><td>北京市海淀区</td><td>高匿代理</td><td>2016年07月19日00时 验证</td></tr><tr><td>182.48.102.2</td><td>9000</td><td>北京市海淀区</td><td>高匿代理</td><td>2016年07月19日00时 验证</td></tr><tr><td>203.91.121.74</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日00时 验证</td></tr><tr><td>203.91.121.74</td><td>3128</td><td>北京市</td><td>高匿代理</td><td>2016年07月19日00时 验证</td></tr></table>
<style>#pagelist a{width:23px;display:block;float:left;}.btn_left{position:absolute;left:0px;top:0px;display:block;width:16px;}.btn_right{position:absolute;right:0px;top:0px;display:block;width:16px;}.mypage a{background:#fff none repeat scroll 0 0;border:1px solid #eaeaea;display:inline;margin:0 0 0 3px;padding:5px 9px;text-decoration:none;}.mypage a:hover{background:#cecece none repeat scroll 0 0;border:1px solid #eaeaea;}a.pagecurrent{background:#e3e3e3 none repeat scroll 0 0;}a.dotdot{background:#fff none repeat scroll 0 0;border:0px;}a.dotdot:hover{background:#fff none repeat scroll 0 0;border:0px;}</style>
<div class="mypage" style="position:relative;margin:10px auto;width:900px;">
<div style="width:740px;overflow:hidden;height:30px;margin:0px auto;"><div id="PageList" style="width:944px;"><a href="/areaindex_1/index" class="pageCurrent">1</a> <a href="/areaindex_1/2.html">2</a> <a href="/areaindex_1/3.html">3</a> <a href="/areaindex_1/4.html">4</a> <a href="/areaindex_1/5.html">5</a> <a href="/areaindex_1/6.html">6</a> <a href="/areaindex_1/7.html">7</a> <a href="/areaindex_1/8.html">8</a> <a href="/areaindex_1/9.html">9</a> <a href="/areaindex_1/10.html">10</a> <a href="javascript:void();" class="dotdot">..</a> <a href="/areaindex_1/59.html">59</a> <a href="/areaindex_1/2.html">&raquo;</a></div></div>
</div>
</div>
</div>
<div align="center"></div>
<div align="center"></div>
<div class="footer">
<div align="center" class="center">
<p>copyright&nbsp;&copy; 2012-2016 66IP.版权所有 粤icp备14092868号-1|QQ一群：<a target="_blank" href="http://shang.qq.com/wpa/qunwpa?idkey=1f3ff00fef89fe190d2606b070fdd656f9ec25ba6a35f9becffa6fd712992ea2" rel="nofollow"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="免费HTTP代理提取66ip.cn" title="免费HTTP代理提取66ip.cn"></a>|QQ二群：<a target="_blank" href="http://shang.qq.com/wpa/qunwpa?idkey=cecdb11c7c6fda939dee876cad2cbaefe02091584788e22bdd3b5815d246e9c0"><img border="0" src="http://pub.idqqimg.com/wpa/images/group.png" alt="免流圣子IP代理提取2群" title="免流圣子IP代理提取2群"></a>
</a><span>|</span><a href="/sitemap.html">网站地图</a></div>
</script>
<script type="text/javascript">
    /*120*300 创建于 2016-02-28*/
var cpro_id = "u2535026";
</script>
<script src="http://cpro.baidustatic.com/cpro/ui/f.js" type="text/javascript"></script>
<script type="text/javascript">
    /* 创建于 2015-05-14*/
    var cpro_psid = "u2103791";
</script>
<script src="http://su.bdimg.com/static/dspui/js/f.js"></script>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "//hm.baidu.com/hm.js?1761fabf3c988e7f04bec51acd4073f4";
  var s = document.getElementsByTagName("script")[0];
  s.parentNode.insertBefore(hm, s);
})();
</script>
</div>
</body>
</html>

'''

root = etree.HTML(html)
proxys = root.xpath(".//*[@id='footer']/div/table/tr[position()>1]")

for proxy in proxys:
    print proxy.xpath('./td[1]')[0].text